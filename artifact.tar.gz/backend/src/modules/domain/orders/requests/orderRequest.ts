export interface OrderRequest {
  productId: string;
  productQuantity: number;
}
